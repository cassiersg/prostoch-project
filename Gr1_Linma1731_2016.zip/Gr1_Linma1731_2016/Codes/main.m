%@Authors Gaetan Cassiers & Bruno Losseau
% @Course LINMA1731 - PROJECT - UCL
% @Date 12/05/16
%  Delivers all the plots asked for the report and saves them.
plot_q2;
plot_q3;
plot_q4;
plot_q5;
plot_q6;
